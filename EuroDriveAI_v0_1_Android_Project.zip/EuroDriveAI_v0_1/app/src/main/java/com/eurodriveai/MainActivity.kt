package com.eurodriveai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EuroDriveScreen() }
    }
}

@Composable
fun EuroDriveScreen() {
    var speed by remember { mutableIntStateOf(0) }
    var steering by remember { mutableIntStateOf(0) }
    var light by remember { mutableStateOf("RED") }
    var instruction by remember { mutableStateOf("Start driving when you are ready.") }
    var distance by remember { mutableIntStateOf(0) }

    MaterialTheme {
        Column(
            modifier = Modifier.fillMaxSize().background(Color(0xFF101820)).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("EuroDrive AI", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Prototype v0.1 • Practice only", color = Color(0xFFB9C6D2), fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))

            Card(
                modifier = Modifier.fillMaxWidth().weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF26343D))
            ) {
                Box(Modifier.fillMaxSize().padding(8.dp)) {
                    Canvas(Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        drawRect(Color(0xFF6A9A58), size = size)
                        drawRect(Color(0xFF444B52), topLeft = Offset(w * 0.25f, 0f),
                            size = Size(w * 0.5f, h))
                        // Road edges
                        drawRect(Color.White, topLeft = Offset(w * 0.25f, 0f), size = Size(5f, h))
                        drawRect(Color.White, topLeft = Offset(w * 0.75f - 5f, 0f), size = Size(5f, h))
                        // Dashed center line
                        var y = -40f
                        while (y < h) {
                            drawRect(Color(0xFFFFD54F), topLeft = Offset(w * 0.5f - 3f, y),
                                size = Size(6f, 36f))
                            y += 72f
                        }
                        // Simple car marker
                        val carX = (w * 0.5f) + steering * w * 0.12f
                        drawRoundRect(Color(0xFF42A5F5),
                            topLeft = Offset(carX - 24f, h * 0.72f),
                            size = Size(48f, 78f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f))
                        drawRect(Color(0xFFBBDEFB), topLeft = Offset(carX - 15f, h * 0.74f),
                            size = Size(30f, 17f))
                        // Traffic light
                        drawRoundRect(Color.DarkGray, topLeft = Offset(w * 0.80f, 22f),
                            size = Size(38f, 105f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f))
                        val red = if (light == "RED") Color.Red else Color(0xFF6D2525)
                        val yellow = if (light == "YELLOW") Color.Yellow else Color(0xFF6D6424)
                        val green = if (light == "GREEN") Color(0xFF00E676) else Color(0xFF245A3C)
                        drawCircle(red, 10f, Offset(w * 0.80f + 19f, 44f))
                        drawCircle(yellow, 10f, Offset(w * 0.80f + 19f, 74f))
                        drawCircle(green, 10f, Offset(w * 0.80f + 19f, 104f))
                    }
                    Text("ROAD VIEW", color = Color.White, modifier = Modifier.align(Alignment.TopStart))
                    Text("Speed: $speed km/h", color = Color.White, modifier = Modifier.align(Alignment.BottomStart))
                }
            }

            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1D2A33))) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("AI INSTRUCTOR", color = Color(0xFF80CBC4), fontWeight = FontWeight.Bold)
                    Text(instruction, color = Color.White, fontSize = 16.sp)
                    Text("Traffic light: $light", color = Color(0xFFFFD54F), fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = {
                    if (light == "RED" && speed > 0) {
                        instruction = "Mistake: the light is red. Stop before the junction."
                    } else {
                        speed = (speed + 10).coerceAtMost(50)
                        distance += 1
                        instruction = if (speed > 30) "Ease off the accelerator and watch your speed." else "Continue straight. Keep a safe speed."
                    }
                }, modifier = Modifier.weight(1f)) { Text("Accelerate") }
                Button(onClick = {
                    speed = (speed - 10).coerceAtLeast(0)
                    instruction = if (speed == 0) "Vehicle stopped. Check mirrors and surroundings." else "Slow down smoothly."
                }, modifier = Modifier.weight(1f)) { Text("Brake") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = {
                    steering = (steering - 1).coerceAtLeast(-1)
                    instruction = "Steer left gently. Check mirrors and blind spot."
                }, modifier = Modifier.weight(1f)) { Text("← Left") }
                OutlinedButton(onClick = {
                    steering = 0
                    instruction = "Drive straight. Keep the car centered in the lane."
                }, modifier = Modifier.weight(1f)) { Text("Straight") }
                OutlinedButton(onClick = {
                    steering = (steering + 1).coerceAtMost(1)
                    instruction = "Steer right gently. Check mirrors and blind spot."
                }, modifier = Modifier.weight(1f)) { Text("Right →") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = {
                    light = when (light) { "RED" -> "GREEN"; "GREEN" -> "YELLOW"; else -> "RED" }
                    instruction = when (light) {
                        "RED" -> "Red light. Stop before the stop line."
                        "YELLOW" -> "Yellow light. Prepare to stop if safe."
                        else -> "Green light. Check the junction before moving."
                    }
                }, modifier = Modifier.weight(1f)) { Text("Change light") }
                OutlinedButton(onClick = {
                    speed = 0; steering = 0; light = "RED"; distance = 0
                    instruction = "Reset complete. Stop at the red light and wait."
                }, modifier = Modifier.weight(1f)) { Text("Reset practice") }
            }
            Spacer(Modifier.height(6.dp))
            Text("This is an early 2D prototype, not an official driving test or a replacement for an instructor.",
                color = Color(0xFFB9C6D2), fontSize = 11.sp)
        }
    }
}
